package com.example.ownerinfo

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView

class MainActivity : Activity() {
    private lateinit var web: WebView

    inner class Bridge {
        private val prefs = getSharedPreferences("owner_info", Context.MODE_PRIVATE)

        @JavascriptInterface
        fun load(): String = prefs.getString("data", "") ?: ""

        @JavascriptInterface
        fun save(json: String) {
            prefs.edit().putString("data", json).apply()
        }

        @JavascriptInterface
        fun clear() {
            prefs.edit().remove("data").apply()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.addJavascriptInterface(Bridge(), "Bridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }
}
